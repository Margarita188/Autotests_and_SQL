data = {
    "doc": {
        "endpoint": "/docs/",
    },
    "log": {
        "endpoint": "/api/logs/main/",
    },


    "ord_new": {
        "title": "Orders - Создание заказа",
        "method": "post",
        "endpoint": "/api/v1/orders",
        "res": {
            "track": 123456
        },
    },
    "ord_get_track": {
        "title": "Orders - Получить заказ по его номеру",
        "method": "get",
        "endpoint": "/api/v1/orders/track",
    },
    "ord_get_all": {
        "title": "Couriers - Получить количество заказов курьера",
        "method": "get",
        "endpoint": "/api/v1/courier/*/ordersCount",
    },
    "ord_count": {
        "title": "Orders - Получение списка заказов",
        "method": "get",
        "endpoint": "/api/v1/orders",
    },


    "ord_apply": {
        "title": "Orders - Принять заказ // accept/id_ord?courierId=213",
        "method": "put",
        "endpoint": "/api/v1/orders/accept/",
        "param": {
            "ord_id": 1,
            "courier_id": 1
        }
    },
    "ord_done": {
        "title": "Orders - Завершить заказ // finish/id_ord",
        "method": "put",
        "endpoint": "/api/v1/orders/finish/",
        "param": {
            "ord_id": 1
        }
    },
    "ord_cancel": {
        "title": "Orders - Отменить заказ // body",
        "method": "put",
        "endpoint": "/api/v1/orders/cancel",
        "param": {
            "track": 1
        }
    },


    "courier_new": {
        "title": "Courier - Создание курьера",
        "method": "post",
        "endpoint": "/api/v1/courier",
        "res": {
            "ok": True
        },
    },
    "courier_login": {
        "title": "Courier - Логин курьера в системе",
        "method": "post",
        "endpoint": "/api/v1/courier/login",
        "res": {
            "id": True
        },
    }
}
