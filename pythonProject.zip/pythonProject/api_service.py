import requests
import urllib.parse
import path

login = "0330f2b9-be28-4442-85b7-42eb65d82e46"
root_url = "https://" + login + ".serverhub.praktikum-services.ru"


# -------------------------

def dict2query_str(dict):
    return urllib.parse.urlencode(dict)


# ------------------------- req

def get(endpoint, param=None):
    url = root_url + endpoint

    if param is not None:
        url += "?" + dict2query_str(param)

    # print("url:", url)
    return requests.get(url)


def post(endpoint, param=None):
    url = root_url + endpoint
    return requests.post(url, headers={"Content-Type": "application/json"}, json=param)


def put(endpoint, param=None):
    url = root_url + endpoint

    if param is not None:
        print("url", url)
        print("param", param)
        return requests.put(url, json=param)

    return requests.put(url)


# -------------------------

def ord_new(param):
    data = path.data["ord_new"]
    return post(data["endpoint"], param)


def ord_get_track(track):
    data = path.data["ord_get_track"]

    return get(data["endpoint"], {"t": track})


def ord_get_all(courier_id):
    data = path.data["ord_get_all"]
    return get(data["endpoint"].replace("*", str(courier_id)))


def ord_count():
    data = path.data["ord_count"]
    return get(data["endpoint"])


# -------------------------

def ord_apply(param):
    data = path.data["ord_apply"]
    url = data["endpoint"] + str(param["id"]) + "?courierId=" + str(param["courier_id"])
    return put(url)


def ord_done(param):
    data = path.data["ord_done"]
    url = data["endpoint"] + str(param["id"])
    return put(url)


def ord_cancel(param):
    data = path.data["ord_cancel"]
    return put(data["endpoint"], {"track": str(param["track"])})


actions = {
    'apply': ord_apply,
    'done': ord_done,
    'cancel': ord_cancel,
}


# -------------------------

def courier_new(param):
    data = path.data["courier_new"]
    return post(data["endpoint"], param)


def courier_login(param):
    data = path.data["courier_login"]
    return post(data["endpoint"], param)
