couriers = {
    "mana": {
        "data": {
            "login": "mana",
            "password": "1234",
            "firstName": "saske"
        },
        "id": None
    },
    "sand": {
        "data": {
            "login": "sand",
            "password": "1234",
            "firstName": "saske"
        },
        "id": None
    },
    "bond": {
        "data": {
            "login": "bond",
            "password": "1234",
            "firstName": "saske"
        },
        "id": None
    },
}

ords = [
    {
        "data": {
            "firstName": "Naruto1",
            "lastName": "Uchiha1",
            "address": "Konoha, 142 apt.",
            "metroStation": 1,
            "phone": "+7 800 355 35 35",
            "rentTime": 5,
            "deliveryDate": "2020-06-06",
            "comment": "Saske, come back to Konoha",
            "color": ["BLACK"]
        },
        "track": None,
        "id": None,
        "courier_id": 1,
        "actions": ["apply"],
    },
    {
        "data": {
            "firstName": "Naruto2",
            "lastName": "Uchiha2",
            "address": "Konoha, 142 apt.",
            "metroStation": 2,
            "phone": "+7 800 355 35 35",
            "rentTime": 5,
            "deliveryDate": "2020-06-06",
            "comment": "Saske, come back to Konoha",
            "color": ["BLACK"]
        },
        "track": None,
        "id": None,
        "courier_id": 2,
        "actions": ["apply"],
    },
    {
        "data": {
            "firstName": "Naruto3",
            "lastName": "Uchiha3",
            "address": "Konoha, 142 apt.",
            "metroStation": 3,
            "phone": "+7 800 355 35 35",
            "rentTime": 5,
            "deliveryDate": "2020-06-06",
            "comment": "Saske, come back to Konoha",
            "color": ["BLACK"]
        },
        "track": None,
        "id": None,
        "courier_id": 3,
        "actions": ["apply", "done"],
    },
    {
        "data": {
            "firstName": "Naruto5",
            "lastName": "Uchiha5",
            "address": "Konoha, 142 apt.",
            "metroStation": 5,
            "phone": "+7 800 355 35 35",
            "rentTime": 5,
            "deliveryDate": "2020-06-06",
            "comment": "Saske, come back to Konoha",
            "color": ["BLACK"]
        },
        "track": None,
        "id": None,
        "courier_id": 2,
        "actions": [],
    },
    {
        "data": {
            "firstName": "Naruto4",
            "lastName": "Uchiha4",
            "address": "Konoha, 142 apt.",
            "metroStation": 4,
            "phone": "+7 800 355 35 35",
            "rentTime": 5,
            "deliveryDate": "2020-06-06",
            "comment": "Saske, come back to Konoha",
            "color": ["BLACK"]
        },
        "track": None,
        "id": None,
        "courier_id": 1,
        "actions": ["apply"],
    },
]

