import api_service
import data

# Маргарита Сильникова. 11 когорта - Финальный проект. Инженер по тестированию плюс

def courier_new():
    for courier in data.couriers:
        courier_data = data.couriers[courier]

        res = api_service.courier_new(courier_data["data"])

        if res.status_code == 201:
            print("courier_new: " + courier)
        else:
            raise Exception("[err] courier_new: "+str(res.status_code))

def courier_login():
    for courier in data.couriers:
        courier_data = data.couriers[courier]

        req_data = courier_data["data"].copy()
        del req_data['firstName']

        res = api_service.courier_login(req_data)

        if res.status_code == 200:
            id = res.json()["id"]
            print("courier_login: "+courier+" | id: "+str(id))
            courier_data["id"] = id
        else:
            raise Exception("[err] courier_login: " + str(res.status_code))

def ord_new():
    for ord_data in data.ords:

        res = api_service.ord_new(ord_data["data"])

        if res.status_code == 201:
            track = res.json()["track"]
            print("ord_track:", track)
            ord_data["track"] = track
        else:
            raise Exception("[err] ord_new: " + str(res.status_code))

def ord_find():
    for ord_data in data.ords:

        track = ord_data["track"]

        res = api_service.ord_get_track(track)
        if res.status_code == 200:
            ord_id = res.json()["order"]["id"]
            print("ord_id: ", ord_id, " | track: ", res.json()["order"]["track"])
            ord_data["id"] = ord_id
        else:
            raise Exception("[err] find_ord: " + str(res.status_code))

def ord_action():
    for ord_data in data.ords:
        actions = ord_data["actions"]

        for action in actions:
            res = api_service.actions[action](ord_data)

            if res.status_code == 200:
                print("action: ", action, res.json())
            else:
                raise Exception("[err] ord_action: " + action, " code: ", res.status_code, "msg: ", res.json())


def gen_data():
    courier_new()
    print("")
    courier_login()
    print("")
    ord_new()
    print("")
    ord_find()
    print("")
    ord_action()

gen_data()