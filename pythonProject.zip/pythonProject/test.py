import api_service

# Маргарита Сильникова. 11 когорта - Финальный проект. Инженер по тестированию плюс

def test():
    print("")
    print("create order:")
    response = api_service.ord_new({
        "firstName": "Naruto",
        "lastName": "Uchiha",
        "address": "Konoha, 142 apt.",
        "metroStation": 4,
        "phone": "+7 800 355 35 35",
        "rentTime": 5,
        "deliveryDate": "2020-06-06",
        "comment": "Saske, come back to Konoha",
        "color": ["BLACK"]
    })

    track = response.json()["track"]
    print("track order: ", track)

    print("get order by track: ")
    response = api_service.ord_get_track(track)
    status_code = response.status_code

    assert response.status_code == 200
